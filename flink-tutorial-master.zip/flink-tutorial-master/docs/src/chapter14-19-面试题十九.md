## 面试题十九

* flink如何实现精准一次性？flink怎么保证容错性，说些checkPoint的内部原理，要很细节的。
* flink的双流join有什么问题？写代码实现interval join的功能，怎么实现？
* 通过双流join进行对账，有没有没join上的情况，interval join的时间是多少，你设置这个时间不会有数据丢失？


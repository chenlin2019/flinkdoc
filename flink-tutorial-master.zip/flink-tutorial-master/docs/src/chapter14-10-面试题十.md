## 面试题十

问题：Flink ExactlyOnce语义是如何实现的，状态是如何存储的？

解答：见教材。从两方面回答：

一，Flink应用程序内部的exactly-once

二，端到端一致性


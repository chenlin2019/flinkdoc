## 从保存点启动应用程序

```sh
$ ./bin/flink run -s <savepointPath> [options] <jobJar> [arguments]
```


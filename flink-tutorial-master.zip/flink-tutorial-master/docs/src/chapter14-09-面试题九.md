## 面试题九

问题：Flink的Watermark详细说明？

解答：见教材。


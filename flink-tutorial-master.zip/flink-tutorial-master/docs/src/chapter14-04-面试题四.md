## 面试题四

问题：Flink的CheckPoint存在哪里？

解答：状态后端。内存，文件系统，或者RocksDB。


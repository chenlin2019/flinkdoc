## 实现有状态的用户自定义函数

我们知道函数有两种状态，键控状态(keyed state)和操作符状态(operator state)。


# 幂等sink连接器
